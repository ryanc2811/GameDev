﻿namespace PongEx1._Game.Behaviour
{
    /// <summary>
    /// interface for the behaviours
    /// </summary>
    public interface IBehaviour
    {
        //method that enacts the behaviour of each behaviour
        void Behaviour();
    }
}
