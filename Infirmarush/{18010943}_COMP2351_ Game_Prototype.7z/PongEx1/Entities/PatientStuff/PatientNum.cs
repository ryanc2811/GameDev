﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1.Entities.PatientStuff
{
    /// <summary>
    /// ENUM FOR DIFFERING BETWEEN EACH PATIENT
    /// </summary>
    public enum PatientNum
    {
        Patient1,
        Patient2
    }
}
