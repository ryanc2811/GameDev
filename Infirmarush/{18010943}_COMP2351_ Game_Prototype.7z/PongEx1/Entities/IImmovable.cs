﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1.Entities
{
    /// <summary>
    /// TAG INTERFACE FOR TAGGING AN ENTITY AS AN IMMOVABLE OBJECT
    /// </summary>
    interface IImmovable
    {
    }
}
