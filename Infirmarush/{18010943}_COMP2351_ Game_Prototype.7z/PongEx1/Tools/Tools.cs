﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1.Tools
{
    /// <summary>
    /// ENUM FOR DIFFERENING BETWEEN EACH TOOL
    /// </summary>
    public enum ToolType
    {
        bonesaw,
        leech
    }
}
